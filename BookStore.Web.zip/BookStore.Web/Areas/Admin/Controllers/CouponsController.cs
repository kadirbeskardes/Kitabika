﻿using BookStore.Service.DTOs;
using BookStore.Service.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace BookStore.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class CouponsController : Controller
    {
        private readonly ICouponService _couponService;

        public CouponsController(ICouponService couponService)
        {
            _couponService = couponService;
        }

        public async Task<IActionResult> Index()
        {
            var coupons = await _couponService.GetAllCouponsAsync();
            return View(coupons);
        }

        public IActionResult Create()
        {
            return View();
        }

        // Areas/Admin/Controllers/CouponsController.cs
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreateCouponDto createCouponDto)
        {
            // ModelState'i temizleyip sadece ilgili alanları kontrol et
            ModelState.Remove("DiscountAmount");
            ModelState.Remove("DiscountPercentage");

            if (createCouponDto.DiscountType == "Fixed")
            {
                ModelState.Remove("DiscountPercentage");
                if (createCouponDto.DiscountAmount <= 0)
                {
                    ModelState.AddModelError(nameof(createCouponDto.DiscountAmount),
                        "Discount amount must be greater than 0");
                }
            }
            else
            {
                ModelState.Remove("DiscountAmount");
                if (createCouponDto.DiscountPercentage <= 0)
                {
                    ModelState.AddModelError(nameof(createCouponDto.DiscountPercentage),
                        "Discount percentage must be greater than 0");
                }
            }

            if (!ModelState.IsValid)
            {
                return View(createCouponDto);
            }

            try
            {
                await _couponService.CreateCouponAsync(createCouponDto);
                TempData["SuccessMessage"] = "Coupon created successfully";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(createCouponDto);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AssignToUser(int couponId, int userId)
        {
            try
            {
                await _couponService.AssignCouponToUserAsync(couponId, userId);
                TempData["SuccessMessage"] = "Coupon assigned to user successfully";
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = ex.Message;
            }

            return RedirectToAction(nameof(Index));
        }
    }
}