﻿// Controllers/CouponsController.cs
using BookStore.Service.DTOs;
using BookStore.Service.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Threading.Tasks;

namespace BookStore.Web.Controllers
{
    [Authorize]
    public class CouponsController : Controller
    {
        private readonly ICouponService _couponService;

        public CouponsController(ICouponService couponService)
        {
            _couponService = couponService;
        }

        public async Task<IActionResult> MyCoupons()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var coupons = await _couponService.GetUserCouponsAsync(userId);
            return View(coupons);
        }

        [HttpPost]
        public async Task<IActionResult> ValidateCoupon(string code, decimal totalAmount)
        {
            var result = await _couponService.ValidateCouponAsync(code, totalAmount);
            return Json(result);
        }
    }
}